# YoRHA-UI-BetterDiscord
Better Discord theme based around NieR: Automata's Menu UI

DOWNLOAD RELEASES HERE https://github.com/AccraZed/YoRHA-UI-BetterDiscord/releases

ONLY WORKS WITH DARK THEME/COZY, AND MAY BREAK IF YOU HAVE SOME APPEARANCE-CHANGING PLUGINS INSTALLED

THANKS TO GOmonkeymanGO FOR LETTING ME USE SOME OF HIS CODE ON HIS NIER UI THEME, https://github.com/ChaseIngebritson/YoRHa-Discord-Theme

![Image of Theme Preview](https://raw.githubusercontent.com/AccraZed/YoRHA-UI-BetterDiscord/master/Previews/Preview%201.jpg)
